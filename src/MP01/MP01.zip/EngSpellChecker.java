package MP01;

public class EngSpellChecker implements ISpellChecker{
    @Override
    public void check(){
        System.out.println("Checking English Spelling...");
    }
}


