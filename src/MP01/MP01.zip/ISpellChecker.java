package MP01;

public interface ISpellChecker {
    public void check();
}

