package MP02;

public interface Comparable {
    int compareTo(Object o1, Object o2); // compareTo 메서드 선언
}
